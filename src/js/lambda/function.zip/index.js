const data = require('data.json');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

function getTheme() {
	const i = Math.floor(Math.random() * data.length);
	return data[i];
}

function generateCSSBody(theme) {
	const cssVarNames = [ 'main', 'h1', 'footer', 'link' ];
	let cssVarStr = '';

	for (i = 0; i < cssVarNames.length; i++) {
		const key = cssVarNames[i];
		const value = theme.colors[i];
		cssVarStr += `--${key}: #${value};`;
	}
	return `:root {${cssVarStr}}`;
}

exports.handler = async (event) => {

	const bucket = event.Records[0].s3.bucket.name;
	const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));

	const theme = getTheme();
	const stylesheet = generateCSSBody(theme);

	try {
		const params = {
			Bucket: bucket,
			Key: key,
			Body: stylesheet,
			ContentType: "text/css"
		}
		const output = await s3.putObject(params).promise();

	} catch(err) {
		console.log(err);
		return;
	}

	console.log(`${bucket}/${key} updated to theme ${theme.title}`);

}